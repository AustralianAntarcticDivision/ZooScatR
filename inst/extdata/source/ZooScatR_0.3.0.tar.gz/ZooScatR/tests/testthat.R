library(testthat)
library(ZooScat)

test_check("ZooScat")
