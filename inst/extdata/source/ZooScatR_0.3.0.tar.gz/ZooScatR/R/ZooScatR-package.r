#' ZooScatR.
#'
#' @name ZooScatR
#' @docType package
NULL
