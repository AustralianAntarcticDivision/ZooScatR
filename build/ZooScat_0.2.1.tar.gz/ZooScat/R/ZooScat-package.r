#' ZooScat.
#'
#' @name ZooScat
#' @docType package
NULL
